import { Barlow_Condensed, Public_Sans } from 'next/font/google';
import Nav from '@/components/Nav';
import './globals.css';

const display = Barlow_Condensed({ subsets: ['latin'], weight: ['500', '600', '700'], variable: '--font-display' });
const body = Public_Sans({ subsets: ['latin'], variable: '--font-body' });

export const metadata = {
  title: 'CMU Lacrosse Kinexon',
  description: 'Kinexon load and performance trends for CMU Lacrosse',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>
        <Nav />
        <main className="page">{children}</main>
      </body>
    </html>
  );
}
