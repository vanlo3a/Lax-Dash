import Link from 'next/link';

export default function NotFound() {
  return <div className="empty"><h1>Page not found</h1><p>That player or page doesn’t exist.</p><Link className="btn primary" href="/roster">See all players</Link></div>;
}
