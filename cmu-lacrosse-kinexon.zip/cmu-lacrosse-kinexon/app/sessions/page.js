import SessionsTable from '@/components/SessionsTable';
import { getSessions } from '@/lib/data';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Sessions, CMU Lacrosse' };

export default async function SessionsPage() {
  return <SessionsTable sessions={await getSessions()} />;
}
