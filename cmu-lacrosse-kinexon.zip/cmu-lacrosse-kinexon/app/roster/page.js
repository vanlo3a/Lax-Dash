import RosterEditor from '@/components/RosterEditor';
import { getPlayers } from '@/lib/data';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Players, CMU Lacrosse' };

export default async function RosterPage() {
  return <RosterEditor players={await getPlayers()} />;
}
