import ImportWizard from '@/components/ImportWizard';

export const metadata = { title: 'Import, CMU Lacrosse' };

export default function ImportPage() {
  return <ImportWizard />;
}
