import { NextResponse } from 'next/server';
import { getSql } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function PATCH(req, { params }) {
  const id = Number(params.id);
  const b = await req.json().catch(() => ({}));
  const sql = getSql();
  const jersey = b.jersey ? String(b.jersey).slice(0, 10) : null;
  const position = b.position ? String(b.position).slice(0, 40) : null;
  const active = b.active !== false;
  const rows = await sql`update players set jersey = ${jersey}, position = ${position}, active = ${active} where id = ${id} returning id`;
  if (!rows.length) return NextResponse.json({ error: 'Player not found.' }, { status: 404 });
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req, { params }) {
  const sql = getSql();
  await sql`delete from players where id = ${Number(params.id)}`;
  return NextResponse.json({ ok: true });
}
