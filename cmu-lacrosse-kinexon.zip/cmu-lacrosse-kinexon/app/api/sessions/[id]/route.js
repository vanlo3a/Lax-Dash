import { NextResponse } from 'next/server';
import { getSql } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function PATCH(req, { params }) {
  const b = await req.json().catch(() => ({}));
  const type = b.type === 'game' ? 'game' : 'practice';
  const sql = getSql();
  const rows = await sql`update sessions set type = ${type} where id = ${Number(params.id)} returning id`;
  if (!rows.length) return NextResponse.json({ error: 'Session not found.' }, { status: 404 });
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req, { params }) {
  const sql = getSql();
  await sql`delete from sessions where id = ${Number(params.id)}`;
  return NextResponse.json({ ok: true });
}
