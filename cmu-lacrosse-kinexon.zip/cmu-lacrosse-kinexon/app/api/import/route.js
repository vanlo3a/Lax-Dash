import { NextResponse } from 'next/server';
import { getSql } from '@/lib/db';
import { METRIC_KEYS } from '@/lib/metrics';

export const dynamic = 'force-dynamic';

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export async function POST(req) {
  let body;
  try { body = await req.json(); } catch { return NextResponse.json({ error: 'Request body is not valid JSON.' }, { status: 400 }); }
  const input = Array.isArray(body?.records) ? body.records : [];

  const records = [];
  for (const r of input) {
    if (!r || typeof r.name !== 'string' || !r.name.trim() || !DATE_RE.test(r.date || '')) continue;
    const rec = {
      name: r.name.trim(),
      date: r.date,
      label: String(r.label ?? '').trim() || 'Session',
      type: r.type === 'game' ? 'game' : 'practice',
      jersey: r.jersey ? String(r.jersey).slice(0, 10) : null,
      position: r.position ? String(r.position).slice(0, 40) : null,
    };
    for (const k of METRIC_KEYS) rec[k] = typeof r[k] === 'number' && isFinite(r[k]) ? r[k] : null;
    records.push(rec);
  }
  if (!records.length) return NextResponse.json({ error: 'No rows had both a player name and a date.' }, { status: 400 });

  const json = JSON.stringify(records);
  const cols = METRIC_KEYS;
  const sql = getSql();

  try {
    await sql(
      `insert into players (name, jersey, position)
       select distinct on (name) name, jersey, position
       from json_to_recordset($1::json) as x(name text, jersey text, position text)
       on conflict (name) do update
         set jersey = coalesce(excluded.jersey, players.jersey),
             position = coalesce(excluded.position, players.position)`,
      [json]
    );
    await sql(
      `insert into sessions (date, label, type)
       select distinct on (date, label) date, label, type
       from json_to_recordset($1::json) as x(date date, label text, type text)
       on conflict (date, label) do update set type = excluded.type`,
      [json]
    );
    await sql(
      `insert into metrics (player_id, session_id, ${cols.join(', ')})
       select p.id, s.id, ${cols.map(c => `x.${c}`).join(', ')}
       from json_to_recordset($1::json) as x(name text, date date, label text, ${cols.map(c => `${c} real`).join(', ')})
       join players p on p.name = x.name
       join sessions s on s.date = x.date and s.label = x.label
       on conflict (player_id, session_id) do update set
         ${cols.map(c => `${c} = coalesce(excluded.${c}, metrics.${c})`).join(',\n         ')}`,
      [json]
    );
  } catch (e) {
    return NextResponse.json({ error: `Database error: ${e.message}` }, { status: 500 });
  }

  return NextResponse.json({
    imported: records.length,
    players: new Set(records.map(r => r.name)).size,
    sessions: new Set(records.map(r => `${r.date}|${r.label}`)).size,
  });
}
