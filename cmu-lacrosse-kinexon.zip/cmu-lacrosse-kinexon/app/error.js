'use client';

export default function Error({ error, reset }) {
  const noDb = /DATABASE_URL|relation .* does not exist/i.test(error?.message || '');
  return (
    <div className="empty">
      <h1>{noDb ? 'The database isn’t set up yet' : 'This page couldn’t load'}</h1>
      <p>{noDb ? 'Connect a Neon Postgres database in Vercel, then run npm run db:setup (see the README).' : error?.message}</p>
      <button type="button" className="btn primary" onClick={reset}>Try again</button>
    </div>
  );
}
