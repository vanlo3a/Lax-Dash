import { notFound } from 'next/navigation';
import PlayerProfile from '@/components/PlayerProfile';
import { getPlayer, getRows } from '@/lib/data';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }) {
  const p = await getPlayer(Number(params.id));
  return { title: p ? `${p.name}, CMU Lacrosse` : 'Player not found' };
}

export default async function PlayerPage({ params }) {
  const id = Number(params.id);
  if (!Number.isInteger(id)) notFound();
  const [player, rows] = await Promise.all([getPlayer(id), getRows()]);
  if (!player) notFound();
  return <PlayerProfile player={player} rows={rows} />;
}
