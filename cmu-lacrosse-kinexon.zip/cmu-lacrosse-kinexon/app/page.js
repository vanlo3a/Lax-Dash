import CoachDashboard from '@/components/CoachDashboard';
import { getRows } from '@/lib/data';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const rows = await getRows();
  return <CoachDashboard rows={rows} />;
}
