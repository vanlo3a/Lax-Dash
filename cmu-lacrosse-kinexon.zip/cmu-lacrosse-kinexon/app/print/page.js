import Link from 'next/link';
import PrintAll from '@/components/PrintAll';
import { getPlayers, getRows } from '@/lib/data';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Print profiles, CMU Lacrosse' };

export default async function PrintPage() {
  const [players, rows] = await Promise.all([getPlayers(), getRows()]);
  const active = players.filter(p => p.active && p.sessions > 0);
  if (!active.length) {
    return <div className="empty"><h1>Nothing to print yet</h1><p>Import Kinexon data first.</p><Link className="btn primary" href="/import">Import a CSV</Link></div>;
  }
  return <PrintAll players={active} rows={rows} />;
}
