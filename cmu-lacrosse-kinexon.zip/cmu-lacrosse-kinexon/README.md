# CMU Lacrosse Kinexon

A coach dashboard and printable player profiles for Kinexon data. Next.js on Vercel, Neon Postgres for storage.

## What's in it

- **Team** (`/`): most recent session vs season average, season trend for any metric (team average per session day, games marked in gold), weekly per-player totals, flags for players whose last session was 25%+ off their own average, and a sortable player table with an early-vs-recent trend.
- **Player profiles** (`/players/[id]`): jersey-number header, personal bests, biggest gains, a season summary for every metric (player avg, team avg, best, early, recent, change), a trend chart per metric with the team average overlaid, and a session log. Filter to practices or games. **Print profile** gives a clean letter-size page.
- **Print profiles** (`/print`): pick players and print them all at once, one player per page (or save as one PDF).
- **Import** (`/import`): upload a Kinexon CSV, check the automatic column matching, choose which phase rows to use, mark games vs practices, import. Re-importing a session updates it instead of duplicating it.
- **Players** and **Sessions**: set jersey numbers and positions, take players off the roster, fix session types, delete bad imports.

Metrics: total distance, high-speed running, max speed, high accels, high decels, Hi-Med IMA (calculated as high accels + high decels when the file doesn't include it), sprints, change of direction, Accumulated Acceleration Load, Player Load, and duration.

## Set up

1. Push this folder to a new GitHub repo and import it in Vercel.
2. In the Vercel project, open **Storage** and add a **Neon** Postgres database. This sets `DATABASE_URL`.
3. Add an environment variable `APP_PASSWORD` (anyone with the password can see and edit everything), then redeploy.
4. Locally, create the tables once:
   ```bash
   npm install
   npx vercel link
   npx vercel env pull .env.local
   npm run db:setup
   ```
5. Open the site, go to **Import**, and upload a Kinexon export. `samples/kinexon-sample.csv` is fake data you can use to try it out; afterwards clear it with `npm run db:clear -- --yes`.

Run locally with `npm run dev` (leave `APP_PASSWORD` empty in `.env.local` to skip sign-in).

## Adjusting it

- **Metrics, labels, units, header matching:** `lib/metrics.js`. Add a header name to a metric's `aliases` if your export uses a different column name. To add a brand-new metric, add it there and add a matching `real` column to `db/schema.sql` (run `alter table metrics add column ...` on the live database).
- **Improvement colouring:** `better: 'higher'` shows increases in green; `'neutral'` (distance, load, duration) is shown without good/bad colour because it depends on the plan.
- **Flag threshold:** `SPIKE` in `components/CoachDashboard.js`.
- **Units:** values are stored as imported (Kinexon defaults to metres and km/h).
