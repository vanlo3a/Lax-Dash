create table if not exists players (
  id          serial primary key,
  name        text not null unique,
  jersey      text,
  position    text,
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists sessions (
  id          serial primary key,
  date        date not null,
  label       text not null default '',
  type        text not null default 'practice' check (type in ('practice', 'game')),
  created_at  timestamptz not null default now(),
  unique (date, label)
);

create table if not exists metrics (
  player_id         int not null references players(id) on delete cascade,
  session_id        int not null references sessions(id) on delete cascade,
  duration_min      real,
  distance_m        real,
  hsr_m             real,
  max_speed         real,
  sprints           real,
  accels_high       real,
  decels_high       real,
  hi_med_ima        real,
  cod               real,
  accum_accel_load  real,
  player_load       real,
  primary key (player_id, session_id)
);

create index if not exists metrics_session_idx on metrics (session_id);
create index if not exists sessions_date_idx on sessions (date);
