import { neon } from '@neondatabase/serverless';

const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
if (!url) { console.error('DATABASE_URL is not set.'); process.exit(1); }
if (!process.argv.includes('--yes')) {
  console.log('This deletes every player, session and metric. Run again with:  npm run db:clear -- --yes');
  process.exit(0);
}
const sql = neon(url);
await sql('truncate metrics, sessions, players restart identity cascade');
console.log('All data cleared.');
