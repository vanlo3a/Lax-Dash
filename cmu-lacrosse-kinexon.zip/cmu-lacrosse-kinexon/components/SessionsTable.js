'use client';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { shortDate } from '@/lib/stats';

export default function SessionsTable({ sessions }) {
  const router = useRouter();
  async function setType(id, type) {
    const res = await fetch(`/api/sessions/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type }) });
    if (res.ok) router.refresh();
  }
  async function remove(s) {
    if (!confirm(`Delete ${s.label} on ${s.date} and its data for ${s.players} players?`)) return;
    const res = await fetch(`/api/sessions/${s.id}`, { method: 'DELETE' });
    if (res.ok) router.refresh();
  }
  if (!sessions.length) {
    return <div className="empty"><h1>No sessions yet</h1><p>Sessions appear here after you import Kinexon data.</p><Link className="btn primary" href="/import">Import a CSV</Link></div>;
  }
  return (
    <div className="stack">
      <div className="page-head"><div><h1>Sessions</h1><p className="sub">Fix whether a session was a game or practice, or delete one that was imported by mistake.</p></div></div>
      <section className="panel">
        <div className="table-wrap">
          <table className="data">
            <thead><tr><th className="left">Date</th><th className="left">Session</th><th className="num">Players</th><th className="left">Type</th><th className="left" aria-label="Actions" /></tr></thead>
            <tbody>
              {sessions.map(s => (
                <tr key={s.id}>
                  <td className="left nowrap">{shortDate(s.date)}, {s.date.slice(0, 4)}</td>
                  <td className="left">{s.label}</td>
                  <td className="num">{s.players}</td>
                  <td className="left">
                    <div className="seg small">
                      {['practice', 'game'].map(t => (
                        <button key={t} type="button" className={s.type === t ? 'on' : ''} aria-pressed={s.type === t} onClick={() => s.type !== t && setType(s.id, t)}>{t === 'game' ? 'Game' : 'Practice'}</button>
                      ))}
                    </div>
                  </td>
                  <td className="left"><button type="button" className="link danger" onClick={() => remove(s)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
