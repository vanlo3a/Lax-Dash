'use client';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { fmt } from '@/lib/metrics';

export const C = { maroon: '#6A0032', gold: '#E0A800', goldBright: '#FFC82E', grey: '#8F868A', grid: '#E6E1E3', ink: '#231F21' };

function GameDot(color) {
  // Games get a gold ring so they stand out from practices.
  return function Dot({ cx, cy, payload, index }) {
    if (cx == null || cy == null) return <g key={index} />;
    const game = payload?.type === 'game';
    return <circle key={index} cx={cx} cy={cy} r={game ? 4.5 : 2.5} fill={game ? C.goldBright : color} stroke={game ? color : 'none'} strokeWidth={game ? 1.5 : 0} />;
  };
}

export function TrendChart({ data, series, metric, height = 220, legend = true }) {
  const tip = v => [`${fmt(v, metric)}${metric.unit ? ' ' + metric.unit : ''}`];
  return (
    <div className="chart" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={C.grid} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: C.grey }} tickLine={false} axisLine={{ stroke: C.grid }} minTickGap={16} />
          <YAxis tick={{ fontSize: 11, fill: C.grey }} tickLine={false} axisLine={false} width={48} tickFormatter={v => fmt(v, { digits: metric.digits > 0 && v < 100 ? 1 : 0 })} domain={['auto', 'auto']} />
          <Tooltip formatter={(v, name) => [tip(v)[0], name]} labelFormatter={(l, p) => (p?.[0]?.payload?.type === 'game' ? `${l} (game)` : l)} contentStyle={{ borderRadius: 6, borderColor: C.grid, fontSize: 12 }} />
          {legend && series.length > 1 && <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} />}
          {series.map(s => (
            <Line key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color} strokeWidth={s.width ?? 2}
              strokeDasharray={s.dash} dot={s.dots === false ? false : GameDot(s.color)} activeDot={{ r: 5 }}
              connectNulls isAnimationActive={false} />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function WeeklyChart({ data, metric, height = 220 }) {
  return (
    <div className="chart" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
          <CartesianGrid stroke={C.grid} vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: C.grey }} tickLine={false} axisLine={{ stroke: C.grid }} />
          <YAxis tick={{ fontSize: 11, fill: C.grey }} tickLine={false} axisLine={false} width={48} tickFormatter={v => fmt(v, { digits: 0 })} />
          <Tooltip formatter={v => [`${fmt(v, metric)}${metric.unit ? ' ' + metric.unit : ''}`, 'Avg per player']} labelFormatter={l => `Week of ${l}`} contentStyle={{ borderRadius: 6, borderColor: C.grid, fontSize: 12 }} />
          <Bar dataKey="avg" fill={C.maroon} radius={[3, 3, 0, 0]} isAnimationActive={false} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
