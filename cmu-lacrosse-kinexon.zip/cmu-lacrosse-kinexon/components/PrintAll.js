'use client';
import { useMemo, useState } from 'react';
import { filterType, teamAvgByDate } from '@/lib/stats';
import PlayerProfile from './PlayerProfile';
import { TypeToggle, PrintButton } from './Controls';

export default function PrintAll({ players, rows }) {
  const [type, setType] = useState('all');
  const [selected, setSelected] = useState(() => new Set(players.map(p => p.id)));
  const teamAvg = useMemo(() => teamAvgByDate(filterType(rows, type)), [rows, type]);
  const chosen = players.filter(p => selected.has(p.id));
  const toggle = id => setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  return (
    <div>
      <div className="panel no-print print-picker">
        <div className="panel-head row">
          <div>
            <h1>Print player profiles</h1>
            <p className="sub">Each player prints on their own pages. Pick who to include, then print or save as PDF from the print dialog.</p>
          </div>
          <div className="controls">
            <TypeToggle value={type} onChange={setType} />
            <PrintButton label={`Print ${chosen.length} ${chosen.length === 1 ? 'profile' : 'profiles'}`} />
          </div>
        </div>
        <div className="picker">
          <button type="button" className="link" onClick={() => setSelected(new Set(players.map(p => p.id)))}>Select all</button>
          <button type="button" className="link" onClick={() => setSelected(new Set())}>Clear</button>
          {players.map(p => (
            <label key={p.id} className="check">
              <input type="checkbox" checked={selected.has(p.id)} onChange={() => toggle(p.id)} />
              {p.jersey ? `#${p.jersey} ` : ''}{p.name}
            </label>
          ))}
        </div>
      </div>
      {chosen.map(p => (
        <PlayerProfile key={`${p.id}-${type}`} player={p} rows={rows} initialType={type} printMode teamAvg={teamAvg} />
      ))}
    </div>
  );
}
