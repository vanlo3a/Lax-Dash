'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Papa from 'papaparse';
import { ID_FIELDS, METRICS, GROUPS, fmt } from '@/lib/metrics';
import { autoMap, buildRecords, distinctSessions, guessPhase } from '@/lib/csv';
import { shortDate } from '@/lib/stats';

function parseText(text, skip) {
  const body = skip > 0 ? text.split(/\r?\n/).slice(skip).join('\n') : text;
  const res = Papa.parse(body, { header: true, skipEmptyLines: 'greedy', transformHeader: h => h.trim() });
  const headers = (res.meta.fields || []).filter(Boolean);
  return { headers, rows: res.data };
}

export default function ImportWizard() {
  const router = useRouter();
  const [fileName, setFileName] = useState('');
  const [text, setText] = useState('');
  const [skip, setSkip] = useState(0);
  const [headers, setHeaders] = useState([]);
  const [rows, setRows] = useState([]);
  const [mapping, setMapping] = useState({});
  const [phase, setPhase] = useState('__all__');
  const [defaultDate, setDefaultDate] = useState('');
  const [sessionTypes, setSessionTypes] = useState({});
  const [status, setStatus] = useState({ state: 'idle' });

  function load(t, s) {
    const { headers: h, rows: r } = parseText(t, s);
    const map = autoMap(h);
    setHeaders(h); setRows(r); setMapping(map); setSessionTypes({}); setStatus({ state: 'idle' });
    setPhase(map.phase ? guessPhase([...new Set(r.map(x => String(x[map.phase] ?? '').trim()))]) : '__all__');
  }

  async function onFile(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    const t = await f.text();
    setFileName(f.name); setText(t); setSkip(0);
    load(t, 0);
  }

  const phases = useMemo(() => (mapping.phase ? [...new Set(rows.map(r => String(r[mapping.phase] ?? '').trim()).filter(Boolean))] : []), [rows, mapping.phase]);
  const built = useMemo(() => (rows.length ? buildRecords(rows, mapping, { phase, defaultDate, sessionTypes }) : null), [rows, mapping, phase, defaultDate, sessionTypes]);
  const sessions = useMemo(() => (built ? distinctSessions(built.records) : []), [built]);
  const mappedMetrics = METRICS.filter(m => mapping[m.key]);
  const imaDerived = !mapping.hi_med_ima && (mapping.accels_high || mapping.decels_high);
  const ready = built && built.records.length > 0 && mapping.name && (mapping.date || defaultDate);

  async function submit() {
    setStatus({ state: 'saving' });
    try {
      const res = await fetch('/api/import', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ records: built.records }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `Import failed (${res.status}).`);
      setStatus({ state: 'done', ...data });
      router.refresh();
    } catch (err) {
      setStatus({ state: 'error', message: err.message });
    }
  }

  const sample = h => {
    const v = rows.find(r => String(r[h] ?? '').trim() !== '');
    return v ? String(v[h]).slice(0, 24) : '';
  };

  const mapRow = f => (
    <tr key={f.key}>
      <td className="left">{f.label}{f.required && <span className="req"> required</span>}{f.unit ? <span className="muted"> {f.unit}</span> : null}</td>
      <td className="left">
        <select className="select" value={mapping[f.key] || ''} onChange={e => setMapping(mp => ({ ...mp, [f.key]: e.target.value || undefined }))}>
          <option value="">Not in this file</option>
          {headers.map(h => <option key={h} value={h}>{h}</option>)}
        </select>
      </td>
      <td className="left muted mono-ish">{mapping[f.key] ? sample(mapping[f.key]) : ''}</td>
    </tr>
  );

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>Import Kinexon data</h1>
          <p className="sub">Upload a CSV export from Kinexon. Re-importing the same session updates it instead of duplicating it.</p>
        </div>
      </div>

      <section className="panel">
        <div className="panel-head"><h2>1. Choose the file</h2></div>
        <div className="row gap wrap">
          <label className="file">
            <input type="file" accept=".csv,text/csv" onChange={onFile} />
            <span className="btn primary">{fileName ? 'Choose a different file' : 'Choose CSV file'}</span>
          </label>
          {fileName && <span className="muted">{fileName}: {rows.length} rows, {headers.length} columns</span>}
        </div>
        {fileName && (
          <div className="row gap wrap small-top">
            <label className="field inline">
              <span>Lines to skip above the header row</span>
              <input className="input narrow" type="number" min={0} max={50} value={skip} onChange={e => { const s = Math.max(0, Number(e.target.value) || 0); setSkip(s); load(text, s); }} />
            </label>
            <span className="muted small">Use this if the export has title lines before the column names.</span>
          </div>
        )}
      </section>

      {headers.length > 0 && (
        <section className="panel">
          <div className="panel-head">
            <h2>2. Check the columns</h2>
            <p className="sub">Columns were matched automatically. Fix anything that’s wrong; the sample shows the first value in each column.</p>
          </div>
          <div className="table-wrap">
            <table className="data map">
              <thead><tr><th className="left">Field</th><th className="left">CSV column</th><th className="left">Sample</th></tr></thead>
              <tbody>
                <tr className="group-row"><th colSpan={3} className="left">Player and session</th></tr>
                {ID_FIELDS.map(mapRow)}
              </tbody>
              {GROUPS.map(g => (
                <tbody key={g.key}>
                  <tr className="group-row"><th colSpan={3} className="left">{g.label}</th></tr>
                  {METRICS.filter(m => m.group === g.key).map(mapRow)}
                </tbody>
              ))}
            </table>
          </div>
          {imaDerived && <p className="note">Hi-Med IMA isn’t in this file, so it will be calculated as high accelerations + high decelerations.</p>}
          <div className="row gap wrap small-top">
            {!mapping.date && (
              <label className="field inline">
                <span>Date for every row</span>
                <input className="input" type="date" value={defaultDate} onChange={e => setDefaultDate(e.target.value)} />
              </label>
            )}
            {phases.length > 0 && (
              <label className="field inline">
                <span>Which phase rows to use</span>
                <select className="select" value={phase} onChange={e => setPhase(e.target.value)}>
                  <option value="__all__">Add up all phases</option>
                  {phases.map(p => <option key={p} value={p}>Only “{p}”</option>)}
                </select>
              </label>
            )}
          </div>
          {phases.length > 0 && phase === '__all__' && phases.some(p => /session|total/i.test(p)) && (
            <p className="note warn">This file has a whole-session row as well as phase rows. Adding up all phases will double count; choose the session row instead.</p>
          )}
        </section>
      )}

      {built && sessions.length > 0 && (
        <section className="panel">
          <div className="panel-head">
            <h2>3. Mark games and practices</h2>
            <p className="sub">Sessions with “game”, “vs” or “@” in the name were marked as games. Change any that are wrong.</p>
          </div>
          <div className="table-wrap">
            <table className="data">
              <thead><tr><th className="left">Date</th><th className="left">Session</th><th className="num">Players</th><th className="left">Type</th></tr></thead>
              <tbody>
                {sessions.map(s => (
                  <tr key={s.key}>
                    <td className="left nowrap">{shortDate(s.date)}, {s.date.slice(0, 4)}</td>
                    <td className="left">{s.label}</td>
                    <td className="num">{s.players}</td>
                    <td className="left">
                      <div className="seg small">
                        {['practice', 'game'].map(t => (
                          <button key={t} type="button" className={s.type === t ? 'on' : ''} aria-pressed={s.type === t} onClick={() => setSessionTypes(st => ({ ...st, [s.key]: t }))}>
                            {t === 'game' ? 'Game' : 'Practice'}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {built && (
        <section className="panel">
          <div className="panel-head"><h2>4. Import</h2></div>
          {built.records.length > 0 ? (
            <p>
              {built.records.length} player-sessions from {new Set(built.records.map(r => r.name)).size} players across {sessions.length} {sessions.length === 1 ? 'session' : 'sessions'}, with {mappedMetrics.length + (imaDerived ? 1 : 0)} metrics.
            </p>
          ) : (
            <p className="note warn">No rows can be imported yet. Every row needs a player name and a date.</p>
          )}
          {(built.skippedNoName > 0 || built.skippedNoDate > 0) && (
            <p className="note">
              Skipping {built.skippedNoName > 0 && `${built.skippedNoName} rows without a player name`}{built.skippedNoName > 0 && built.skippedNoDate > 0 && ' and '}{built.skippedNoDate > 0 && `${built.skippedNoDate} rows without a readable date`}.
            </p>
          )}
          {built.records.length > 0 && (
            <div className="table-wrap preview">
              <table className="data">
                <thead><tr><th className="left">Player</th><th className="left">Date</th>{mappedMetrics.slice(0, 6).map(m => <th key={m.key} className="num">{m.short}</th>)}</tr></thead>
                <tbody>
                  {built.records.slice(0, 5).map((r, i) => (
                    <tr key={i}><td className="left">{r.name}</td><td className="left nowrap">{r.date}</td>{mappedMetrics.slice(0, 6).map(m => <td key={m.key} className="num">{fmt(r[m.key], m)}</td>)}</tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="row gap wrap small-top">
            <button type="button" className="btn primary" disabled={!ready || status.state === 'saving'} onClick={submit}>
              {status.state === 'saving' ? 'Importing…' : `Import ${built.records.length} rows`}
            </button>
            {status.state === 'done' && (
              <span className="ok">Imported {status.imported} rows ({status.players} players, {status.sessions} sessions). <Link href="/">Open the team overview</Link></span>
            )}
            {status.state === 'error' && <span className="err">{status.message}</span>}
          </div>
        </section>
      )}
    </div>
  );
}
