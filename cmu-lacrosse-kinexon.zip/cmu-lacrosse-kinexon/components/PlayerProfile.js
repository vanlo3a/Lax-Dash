'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { METRICS, METRIC_BY_KEY, GROUPS, fmt, fmtPct } from '@/lib/metrics';
import { filterType, teamAvgByDate, sortedPlayerRows, improvement, mean, bestOf, shortDate, num } from '@/lib/stats';
import { TypeToggle, PrintButton } from './Controls';
import { TrendChart, C } from './Charts';

const HIGHLIGHTS = ['max_speed', 'hsr_m', 'sprints', 'hi_med_ima'];
const LOG_COLS = ['duration_min', 'distance_m', 'hsr_m', 'max_speed', 'sprints', 'hi_med_ima', 'cod', 'accum_accel_load'];
const TYPE_LABEL = { all: 'All sessions', practice: 'Practices only', game: 'Games only' };

function tone(pct, better) {
  if (pct == null || better === 'neutral' || Math.abs(pct) < 2) return 'flat';
  return pct > 0 ? 'up' : 'down';
}

export default function PlayerProfile({ player, rows, initialType = 'all', printMode = false, teamAvg: teamAvgProp }) {
  const [type, setType] = useState(initialType);
  const [showAll, setShowAll] = useState(false);

  const filtered = useMemo(() => filterType(rows, type), [rows, type]);
  const mine = useMemo(() => sortedPlayerRows(filtered, player.id), [filtered, player.id]);
  const teamAvg = useMemo(() => teamAvgProp || teamAvgByDate(filtered), [filtered, teamAvgProp]);

  const summary = useMemo(() => METRICS.map(m => {
    const vals = mine.map(r => r[m.key]);
    const teamVals = mine.map(r => teamAvg[r.date]?.[m.key]);
    return { m, avg: mean(vals), teamAvg: mean(teamVals), best: bestOf(mine, m.key), imp: improvement(vals), n: vals.filter(num).length };
  }), [mine, teamAvg]);

  const charts = useMemo(() => METRICS.map(m => ({
    m,
    data: mine.map(r => ({ label: shortDate(r.date), date: r.date, type: r.type, you: r[m.key], team: teamAvg[r.date]?.[m.key] ?? null })),
  })).filter(c => c.data.some(d => num(d.you))), [mine, teamAvg]);

  const first = mine[0], last = mine[mine.length - 1];
  const log = [...mine].reverse();
  const shownLog = showAll ? log : log.slice(0, 10);
  const improved = summary.filter(s => s.m.better === 'higher' && s.imp && s.imp.pct >= 2).sort((a, b) => b.imp.pct - a.imp.pct);

  return (
    <article className="profile">
      <header className="hero">
        <div className="hero-num" aria-hidden={!player.jersey}>{player.jersey || '–'}</div>
        <div className="hero-text">
          <h1>{player.name}</h1>
          <p className="hero-meta">
            {[player.position, `${mine.length} ${mine.length === 1 ? 'session' : 'sessions'}`, first && `${shortDate(first.date)} to ${shortDate(last.date)}`].filter(Boolean).join(', ')}
          </p>
          <p className="print-only hero-meta">{TYPE_LABEL[type]}</p>
        </div>
        {!printMode && (
          <div className="hero-actions no-print">
            <TypeToggle value={type} onChange={setType} />
            <PrintButton label="Print profile" />
          </div>
        )}
      </header>

      {!mine.length ? (
        <p className="empty-inline">No {type === 'all' ? '' : type + ' '}sessions for this player yet.</p>
      ) : (
        <>
          <section className="bests">
            {HIGHLIGHTS.map(k => {
              const s = summary.find(x => x.m.key === k);
              if (!s.best) return null;
              return (
                <div key={k} className="best">
                  <span className="best-label">Best {s.m.label.toLowerCase()}</span>
                  <span className="best-value">{fmt(s.best.value, s.m)}<small>{s.m.unit}</small></span>
                  <span className="best-foot">{shortDate(s.best.date)}{s.best.type === 'game' ? ', game' : ''}</span>
                </div>
              );
            })}
          </section>

          {improved.length > 0 && (
            <p className="callout">
              Biggest gains since the start of the season: {improved.slice(0, 3).map((s, i) => (
                <span key={s.m.key}>{i > 0 ? (i === Math.min(improved.length, 3) - 1 ? ' and ' : ', ') : ''}<strong>{s.m.label.toLowerCase()}</strong> ({fmtPct(s.imp.pct)})</span>
              ))}.
            </p>
          )}

          <section className="panel card">
            <div className="panel-head">
              <h2>Season summary</h2>
              <p className="sub">“Early” is the average of the first sessions and “recent” the average of the latest ones (up to three each).</p>
            </div>
            <div className="table-wrap">
              <table className="data summary">
                <thead>
                  <tr>
                    <th className="left">Metric</th>
                    <th className="num">Your avg</th>
                    <th className="num">Team avg</th>
                    <th className="num">Best</th>
                    <th className="num">Early</th>
                    <th className="num">Recent</th>
                    <th className="num">Change</th>
                  </tr>
                </thead>
                {GROUPS.map(g => (
                  <tbody key={g.key}>
                    <tr className="group-row"><th colSpan={7} className="left">{g.label}</th></tr>
                    {summary.filter(s => s.m.group === g.key && s.n > 0).map(s => (
                      <tr key={s.m.key}>
                        <td className="left">{s.m.label}{s.m.unit && <span className="muted"> {s.m.unit}</span>}</td>
                        <td className="num strong">{fmt(s.avg, s.m)}</td>
                        <td className="num muted">{fmt(s.teamAvg, s.m)}</td>
                        <td className="num">{fmt(s.best?.value, s.m)}</td>
                        <td className="num">{fmt(s.imp?.early, s.m)}</td>
                        <td className="num">{fmt(s.imp?.recent, s.m)}</td>
                        <td className="num"><span className={`delta ${tone(s.imp?.pct, s.m.better)}`}>{fmtPct(s.imp?.pct)}</span></td>
                      </tr>
                    ))}
                  </tbody>
                ))}
              </table>
            </div>
          </section>

          <section className="chart-section">
            <div className="panel-head">
              <h2>Trends</h2>
              <p className="sub">
                <span className="key key-you" /> {player.name.split(' ')[0]}
                <span className="key key-team" /> Team average on the same days
                <span className="key key-game" /> Game
              </p>
            </div>
            <div className="chart-grid">
              {charts.map(({ m, data }) => (
                <div key={m.key} className="card chart-card">
                  <h3>{m.label}{m.unit && <span className="muted"> {m.unit}</span>}</h3>
                  <TrendChart
                    data={data}
                    metric={m}
                    height={180}
                    legend={false}
                    series={[
                      { key: 'team', name: 'Team avg', color: C.grey, dash: '4 4', width: 1.5, dots: false },
                      { key: 'you', name: player.name.split(' ')[0], color: C.maroon, width: 2.25 },
                    ]}
                  />
                </div>
              ))}
            </div>
          </section>

          <section className="panel card log">
            <div className="panel-head row">
              <div>
                <h2>Session log</h2>
                <p className="sub">{showAll ? `All ${log.length} sessions` : `Latest ${Math.min(10, log.length)} of ${log.length}`}, newest first</p>
              </div>
              {log.length > 10 && (
                <button type="button" className="btn no-print" onClick={() => setShowAll(v => !v)}>{showAll ? 'Show latest 10' : 'Show all sessions'}</button>
              )}
            </div>
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th className="left">Date</th>
                    <th className="left">Session</th>
                    {LOG_COLS.map(k => <th key={k} className="num">{METRIC_BY_KEY[k].short}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {shownLog.map(r => (
                    <tr key={r.session_id}>
                      <td className="left nowrap">{shortDate(r.date)}</td>
                      <td className="left">{r.label}{r.type === 'game' && <span className="chip game">Game</span>}</td>
                      {LOG_COLS.map(k => <td key={k} className="num">{fmt(r[k], METRIC_BY_KEY[k])}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {!printMode && (
        <p className="no-print back"><Link href="/roster">All players</Link></p>
      )}
    </article>
  );
}
