'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { METRIC_BY_KEY, fmt, fmtPct } from '@/lib/metrics';
import { filterType, teamByDate, weekly, playerSummaries, mean, pctChange, shortDate } from '@/lib/stats';
import { TypeToggle, MetricSelect, PrintButton } from './Controls';
import { TrendChart, WeeklyChart, C } from './Charts';

const HEADLINE = ['distance_m', 'hsr_m', 'max_speed', 'hi_med_ima', 'sprints', 'accum_accel_load'];
const SPIKE = 25; // % above/below a player's own average that gets flagged

function Delta({ pct, better }) {
  if (pct == null) return <span className="delta">–</span>;
  const tone = better === 'neutral' || Math.abs(pct) < 2 ? 'flat' : pct > 0 ? 'up' : 'down';
  return <span className={`delta ${tone}`}>{fmtPct(pct)}</span>;
}

export default function CoachDashboard({ rows }) {
  const [type, setType] = useState('all');
  const [metric, setMetric] = useState('distance_m');
  const [sort, setSort] = useState({ key: 'avg', dir: -1 });
  const m = METRIC_BY_KEY[metric];

  const filtered = useMemo(() => filterType(rows, type), [rows, type]);
  const trend = useMemo(() => teamByDate(filtered, metric), [filtered, metric]);
  const week = useMemo(() => weekly(filtered, metric), [filtered, metric]);
  const table = useMemo(() => {
    const s = playerSummaries(filtered, metric);
    const k = sort.key;
    return s.sort((a, b) => {
      const av = a[k], bv = b[k];
      if (k === 'name') return sort.dir * String(av).localeCompare(String(bv));
      if (av == null) return 1;
      if (bv == null) return -1;
      return sort.dir * (av - bv);
    });
  }, [filtered, metric, sort]);

  const latest = useMemo(() => {
    const dates = [...new Set(filtered.map(r => r.date))].sort();
    const last = dates[dates.length - 1];
    if (!last) return null;
    const lastRows = filtered.filter(r => r.date === last);
    return {
      date: last,
      type: lastRows.some(r => r.type === 'game') ? 'game' : 'practice',
      players: new Set(lastRows.map(r => r.player_id)).size,
      tiles: HEADLINE.map(k => {
        const season = mean(teamByDate(filtered, k).map(p => p.avg));
        const now = mean(lastRows.map(r => r[k]));
        return { key: k, now, season, pct: pctChange(now, season) };
      }),
    };
  }, [filtered]);

  if (!rows.length) {
    return (
      <div className="empty">
        <h1>No Kinexon data yet</h1>
        <p>Import a Kinexon CSV export to start building the season picture for the team and each player.</p>
        <Link className="btn primary" href="/import">Import a CSV</Link>
      </div>
    );
  }

  const th = (key, label, cls = 'num') => (
    <th className={cls}>
      <button type="button" className="sort" onClick={() => setSort(s => ({ key, dir: s.key === key ? -s.dir : key === 'name' ? 1 : -1 }))}>
        {label}{sort.key === key ? (sort.dir === 1 ? ' ▲' : ' ▼') : ''}
      </button>
    </th>
  );

  const unit = m.unit ? ` (${m.unit})` : '';

  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>Team overview</h1>
          <p className="sub">{new Set(rows.map(r => r.player_id)).size} players, {new Set(rows.map(r => r.date)).size} session days, {shortDate(rows[0].date)} to {shortDate(rows[rows.length - 1].date)}</p>
        </div>
        <div className="controls no-print">
          <TypeToggle value={type} onChange={setType} />
          <PrintButton />
        </div>
      </div>

      {latest && (
        <section className="panel">
          <div className="panel-head">
            <h2>Most recent: {shortDate(latest.date)} {latest.type === 'game' ? 'game' : 'practice'}</h2>
            <p className="sub">Team average, {latest.players} players, compared with the season average</p>
          </div>
          <div className="tiles">
            {latest.tiles.map(t => {
              const tm = METRIC_BY_KEY[t.key];
              return (
                <button key={t.key} type="button" className={`tile ${metric === t.key ? 'on' : ''}`} onClick={() => setMetric(t.key)}>
                  <span className="tile-label">{tm.label}</span>
                  <span className="tile-value">{fmt(t.now, tm)}<small>{tm.unit}</small></span>
                  <span className="tile-foot">Season {fmt(t.season, tm)} <Delta pct={t.pct} better="neutral" /></span>
                </button>
              );
            })}
          </div>
        </section>
      )}

      <section className="panel">
        <div className="panel-head row">
          <div>
            <h2>{m.label} across the season</h2>
            <p className="sub">Team average per session day{m.agg === 'max' ? '' : ', with the highest individual value'}. Gold dots are games.</p>
          </div>
          <label className="field no-print">
            <span>Metric</span>
            <MetricSelect value={metric} onChange={setMetric} />
          </label>
        </div>
        <TrendChart
          data={trend}
          metric={m}
          height={280}
          series={[
            { key: 'avg', name: 'Team average', color: C.maroon, width: 2.5 },
            { key: 'max', name: 'Highest player', color: C.grey, dash: '4 4', width: 1.5, dots: false },
          ]}
        />
      </section>

      <div className="two-col">
        <section className="panel">
          <div className="panel-head">
            <h2>Weekly {m.agg === 'max' ? 'best' : 'total'}, per player</h2>
            <p className="sub">{m.agg === 'max' ? 'Each player’s top value that week' : 'Each player’s total for the week'}, averaged across the team{unit}</p>
          </div>
          <WeeklyChart data={week} metric={m} />
        </section>
        <section className="panel">
          <div className="panel-head">
            <h2>Flags from each player’s last session</h2>
            <p className="sub">More than {SPIKE}% above or below their own season average for {m.label.toLowerCase()}</p>
          </div>
          <ul className="flags">
            {table.filter(p => p.lastVsAvg != null && Math.abs(p.lastVsAvg) >= SPIKE).slice(0, 10).map(p => (
              <li key={p.id}>
                <Link href={`/players/${p.id}`}>{p.jersey ? `#${p.jersey} ` : ''}{p.name}</Link>
                <span className="muted">{shortDate(p.lastDate)}: {fmt(p.last, m)} vs avg {fmt(p.avg, m)}</span>
                <span className={`chip ${p.lastVsAvg > 0 ? 'hi' : 'lo'}`}>{fmtPct(p.lastVsAvg)}</span>
              </li>
            ))}
            {!table.some(p => p.lastVsAvg != null && Math.abs(p.lastVsAvg) >= SPIKE) && <li className="muted">Everyone’s last session was within {SPIKE}% of their average.</li>}
          </ul>
        </section>
      </div>

      <section className="panel">
        <div className="panel-head">
          <h2>Players: {m.label.toLowerCase()}{unit}</h2>
          <p className="sub">Trend compares each player’s first three sessions with their last three. Click a column to sort, or a name to open the profile.</p>
        </div>
        <div className="table-wrap">
          <table className="data">
            <thead>
              <tr>
                {th('name', 'Player', 'left')}
                <th className="left">Pos</th>
                {th('n', 'Sessions')}
                {th('avg', 'Season avg')}
                {th('best', 'Best')}
                {th('last', 'Last')}
                {th('lastVsAvg', 'Last vs avg')}
                {th('trend', 'Trend')}
              </tr>
            </thead>
            <tbody>
              {table.map(p => (
                <tr key={p.id}>
                  <td className="left"><Link href={`/players/${p.id}`} className="player-link"><span className="jn">{p.jersey || ''}</span>{p.name}</Link></td>
                  <td className="left muted">{p.position || ''}</td>
                  <td className="num">{p.n}</td>
                  <td className="num">{fmt(p.avg, m)}</td>
                  <td className="num">{fmt(p.best, m)}</td>
                  <td className="num">{fmt(p.last, m)}</td>
                  <td className="num"><Delta pct={p.lastVsAvg} better="neutral" /></td>
                  <td className="num"><Delta pct={p.trend} better={m.better} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
