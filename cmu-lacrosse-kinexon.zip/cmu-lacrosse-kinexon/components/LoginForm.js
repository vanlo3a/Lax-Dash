'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

export default function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setError('');
    const res = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) });
    setBusy(false);
    if (res.ok) { router.replace(params.get('next') || '/'); router.refresh(); }
    else setError((await res.json().catch(() => ({}))).error || 'Sign-in failed.');
  }

  return (
    <form className="login" onSubmit={submit}>
      <div className="login-mark">CMU <span>Lacrosse</span></div>
      <label className="field">
        <span>Password</span>
        <input className="input" type="password" autoFocus autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} />
      </label>
      {error && <p className="err">{error}</p>}
      <button type="submit" className="btn primary wide" disabled={busy || !password}>{busy ? 'Signing in…' : 'Sign in'}</button>
    </form>
  );
}
