'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const LINKS = [
  { href: '/', label: 'Team' },
  { href: '/roster', label: 'Players' },
  { href: '/sessions', label: 'Sessions' },
  { href: '/import', label: 'Import' },
  { href: '/print', label: 'Print profiles' },
];

export default function Nav() {
  const path = usePathname();
  if (path === '/login') return null;
  const active = href => (href === '/' ? path === '/' : path.startsWith(href) || (href === '/roster' && path.startsWith('/players')));
  return (
    <header className="topbar no-print">
      <div className="topbar-inner">
        <Link href="/" className="wordmark">
          <span className="wm-c">CMU</span> Lacrosse <span className="wm-sub">Kinexon</span>
        </Link>
        <nav>
          {LINKS.map(l => (
            <Link key={l.href} href={l.href} className={active(l.href) ? 'on' : ''} aria-current={active(l.href) ? 'page' : undefined}>
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
