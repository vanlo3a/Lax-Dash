'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

function Row({ p }) {
  const router = useRouter();
  const [jersey, setJersey] = useState(p.jersey || '');
  const [position, setPosition] = useState(p.position || '');
  const [active, setActive] = useState(p.active);
  const [state, setState] = useState('');
  const dirty = jersey !== (p.jersey || '') || position !== (p.position || '') || active !== p.active;

  async function save() {
    setState('saving');
    const res = await fetch(`/api/players/${p.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jersey, position, active }) });
    setState(res.ok ? 'Saved' : 'Couldn’t save');
    if (res.ok) router.refresh();
  }
  async function remove() {
    if (!confirm(`Delete ${p.name} and all of their Kinexon data? This can’t be undone.`)) return;
    const res = await fetch(`/api/players/${p.id}`, { method: 'DELETE' });
    if (res.ok) router.refresh(); else setState('Couldn’t delete');
  }

  return (
    <tr className={active ? '' : 'inactive'}>
      <td className="left"><Link href={`/players/${p.id}`} className="player-link">{p.name}</Link></td>
      <td className="left"><input className="input narrow" aria-label={`Jersey for ${p.name}`} value={jersey} onChange={e => setJersey(e.target.value)} /></td>
      <td className="left"><input className="input" aria-label={`Position for ${p.name}`} value={position} placeholder="Attack, Midfield…" onChange={e => setPosition(e.target.value)} /></td>
      <td className="num">{p.sessions}</td>
      <td className="left"><label className="check"><input type="checkbox" checked={active} onChange={e => setActive(e.target.checked)} /> On roster</label></td>
      <td className="left nowrap">
        <button type="button" className="btn small" disabled={!dirty || state === 'saving'} onClick={save}>Save</button>
        <button type="button" className="link danger" onClick={remove}>Delete</button>
        {state && state !== 'saving' && <span className="muted small"> {state}</span>}
      </td>
    </tr>
  );
}

export default function RosterEditor({ players }) {
  if (!players.length) {
    return <div className="empty"><h1>No players yet</h1><p>Players are added automatically when you import a Kinexon CSV.</p><Link className="btn primary" href="/import">Import a CSV</Link></div>;
  }
  return (
    <div className="stack">
      <div className="page-head">
        <div>
          <h1>Players</h1>
          <p className="sub">Open a player to see their profile. Players taken off the roster are hidden from the dashboards but keep their data.</p>
        </div>
      </div>
      <section className="panel">
        <div className="table-wrap">
          <table className="data">
            <thead><tr><th className="left">Name</th><th className="left">Jersey</th><th className="left">Position</th><th className="num">Sessions</th><th className="left">Status</th><th className="left" aria-label="Actions" /></tr></thead>
            <tbody>{players.map(p => <Row key={p.id} p={p} />)}</tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
