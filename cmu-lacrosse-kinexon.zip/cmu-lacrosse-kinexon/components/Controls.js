'use client';
import { GROUPS, METRICS } from '@/lib/metrics';

export function TypeToggle({ value, onChange }) {
  const opts = [['all', 'All sessions'], ['practice', 'Practices'], ['game', 'Games']];
  return (
    <div className="seg" role="group" aria-label="Session type">
      {opts.map(([v, l]) => (
        <button key={v} type="button" className={value === v ? 'on' : ''} aria-pressed={value === v} onClick={() => onChange(v)}>{l}</button>
      ))}
    </div>
  );
}

export function MetricSelect({ value, onChange, id = 'metric' }) {
  return (
    <select id={id} className="select" value={value} onChange={e => onChange(e.target.value)}>
      {GROUPS.map(g => (
        <optgroup key={g.key} label={g.label}>
          {METRICS.filter(m => m.group === g.key).map(m => (
            <option key={m.key} value={m.key}>{m.label}{m.unit ? ` (${m.unit})` : ''}</option>
          ))}
        </optgroup>
      ))}
    </select>
  );
}

export function PrintButton({ label = 'Print' }) {
  return <button type="button" className="btn no-print" onClick={() => window.print()}>{label}</button>;
}
